 <!-- Footer  -->
 <footer class="footer">
            <p>&copy; Jordan English</p>


                <!-- Back to top Button -->
     <div id="back-to-top">
        <a href="#">
        Back to top 
       </a>
    </div>
      
</footer>