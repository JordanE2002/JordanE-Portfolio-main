

     <!-- Page Content -->
     <div id="main-content">
        <!-- Header -->
        <section id="home" class="header">
            <div class="header-content">
                <h1 id="greeting-text"></h1> <!-- This will display "Hello, I am Jordan English." -->
                <p id="portfolio-text"></p> <!-- This will display "This is my Portfolio." -->
            </div>
            <img src="images/sausage-dog.webp" alt="sausage-dog" class="banner-img">
        </section>
